package AgendaContatos;

import java.util.Date;

import AgendaContatos.ContatoDAO;
import AgendaContatos.ContatoDAO;

public class TesteAgenda {
	
	public static void main(String [] args) {
		
		ContatoDAO contatoDAO = new ContatoDAO();
		
		
		/*
		Contato contato = new Contato();
		contato.setNome("HENRIQUE DELLOSSO");
		contato.setIdade(45);
		contato.setDataCadastros(new Date());
		contatoDAO.save(contato);
		
		Contato contato2 = new Contato();
		contato2.setNome("Alexandre Brito");
		contato2.setIdade(25);
		contato2.setDataCadastros(new Date());
		contatoDAO.save(contato2);
		*/
		
		/*
		contatoDAO.apagar(4);
		*/
		
		/*
		Contato contato1 = new Contato();
		contato1.setId(1);
		contato1.setNome("Nome Novo");
		contato1.setIdade(25);
		contato1.setDataCadastros(new Date());
		
		contatoDAO.atualizar(contato1);
		*/
		
		for(Contato c: contatoDAO.getContatos()) {
			System.out.println(" Nome: " + c.getNome());
			System.out.println(" idade: " + c.getIdade());
			System.out.println(" data: " + c.getDataCadastros());
		}
	}
}
